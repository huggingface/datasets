Asian Language Treebank Parallel Corpus

				Masao Utiyama
				Fri Jul  1 13:21:26 JST 2016