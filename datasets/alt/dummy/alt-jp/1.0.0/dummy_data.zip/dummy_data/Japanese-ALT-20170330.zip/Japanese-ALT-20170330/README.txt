Japanese ALT 

				Masao Utiyama
				Thu Mar 30 15:21:49 JST 2017