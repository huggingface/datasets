NOVA Tokenized/POS-tagged Khmer ALT

					Masao Utiyama
					Thu Nov 01 16:00:00 JST 2018