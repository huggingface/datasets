English ALT 

				Masao Utiyama
				Sat Jan  7 05:24:38 JST 2017