Izmjene prilogâ Konvenciji iz Lugana od 30. listopada 2007.
U skladu s obavijestima depozitara Švicarske od 11. travnja 2016. i 27. svibnja 2016. tekst priloga od I. do IV. te IX. mijenja se kako slijedi:
[Prilog I.
Pravila o nadležnosti iz članka 3. stavka 2. i članka 4. stavka 2.
Konvencije jesu sljedeća:]