Ispravak Drugog dodatnog protokola uz Sporazum o pridruživanju između Europske zajednice i njezinih država članica, s jedne strane, i Republike Čilea, s druge strane, kako bi se uzelo u obzir pristupanje Republike Bugarske i Rumunjske Europskoj uniji
(Službeni list Europske unije L 251 od 26. rujna 2007.)
(Posebno izdanje Službenog lista Europske unije 11/ sv.
35 od 2. travnja 2013.)
Na stranicama od 148. do 161., u Prilogu III., tablici „I. Horizontalne obveze”, u naslovu: