DBPedia Ontology Classification Dataset

Version 2, Updated 09/09/2015