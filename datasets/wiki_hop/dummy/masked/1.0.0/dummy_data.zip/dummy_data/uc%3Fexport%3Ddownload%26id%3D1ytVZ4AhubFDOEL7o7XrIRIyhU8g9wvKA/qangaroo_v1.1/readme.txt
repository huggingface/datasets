QAngaroo contains two datasets: MedHop and WikiHop.

These datasets focus on multi-step (alias multi-hop) reading comprehension.

The datasets are released under CC BY-SA 3.0 (https://creativecommons.org/licenses/by-sa/3.0/).