The directory contains 3 files: 

parallelTweets.csv 
accountList.csv
countryTopicAnnotation.csv