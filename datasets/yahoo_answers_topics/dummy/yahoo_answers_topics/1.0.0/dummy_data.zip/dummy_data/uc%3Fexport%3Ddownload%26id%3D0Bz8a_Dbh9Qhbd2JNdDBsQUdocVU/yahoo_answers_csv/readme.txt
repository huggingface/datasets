Yahoo! Answers Topic Classification Dataset

Version 2, Updated 09/09/2015