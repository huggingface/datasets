Source: Project Gutenberg
TAJEMNICA BASKERVILLE'ÓW
Conana Doyle'a
I. Pan Sherlock Holmes.
Pan Sherlock Holmes zwykł był wstawać późno, o ile nie czuwał przez całą noc, a zdarzało mu się to nieraz.