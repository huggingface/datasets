ASCII (czyt.
"aski; "ang.
"American Standard Code for Information Interchange") – 7-bitowy kod przyporządkowujący liczby z zakresu 0−127: literom alfabetu angielskiego, cyfrom, znakom przestankowym i innym symbolom oraz poleceniom sterującym.
Na przykład litera „a” jest kodowana jako liczba 97, a znak spacji jest kodowany jako 32.
==Podział==Znaki ASCII dzielą się na :* drukowalne: 95 znaków o kodach 32−126* sterujące: 33 znaki o kodach 0−31 i 127Litery, cyfry, znaki interpunkcyjne oraz kilka innych znaków (spacja, @) tworzą zbiór drukowalnych znaków ASCII.