Huggingface/datasets-ready version of The Stanford Sentiment Treebank V1.0

This archive makes SST available for Huggingface's Datasets library (https://github.com/huggingface/datasets)

This version of SST includes the original text files present in