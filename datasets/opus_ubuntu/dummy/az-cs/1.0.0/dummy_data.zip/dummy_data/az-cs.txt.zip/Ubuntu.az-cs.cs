Obashuje Gmail, Google Docs, Google+, YouTube a Picasu
Diagnostika
Nastavení, co se bude zaznamenávat do vašeho záznamu činností Zeitgeist
Nástroje Správce soukromí a činností
Bezpečnost & Soukromí