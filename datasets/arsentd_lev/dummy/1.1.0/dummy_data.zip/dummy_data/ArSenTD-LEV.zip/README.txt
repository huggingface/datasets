The Arabic Sentiment Twitter Dataset for Levantine dialect (ArSenTD-LEV) contains 4,000 tweets written in Arabic and equally retrieved from Jordan, Lebanon, Palestine and Syria.

The file "ArSenTD-LEV.tsv" is a tab-separated file that contains the corpus and has the following fields:

1. 'Tweet': the text content of the tweet