LICENSE
=======

This data is released under the Creative Commons Public License. A copy is included with the data.