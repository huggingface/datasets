A ziemia była niekształtowna i próżna, i ciemność była nad przepaścią, a Duch Boży unaszał się nad wodami.
I rzekł Bóg: Niech będzie światłość; i stała się światłość.
I widział Bóg światłość, że była dobra; i uczynił Bóg rozdział między światłością i między ciemnością.
I nazwał Bóg światłość dniem a ciemność nazwał nocą; i stał się wieczór, i stał się zaranek, dzień pierwszy.
Potem rzekł Bóg: Niech będzie rozpostarcie, w pośrodku wód, a niech dzieli wody od wód.