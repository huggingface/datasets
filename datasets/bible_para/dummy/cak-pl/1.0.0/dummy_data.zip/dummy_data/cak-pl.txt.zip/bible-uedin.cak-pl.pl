Księga o rodzie Jezusa Chrystusa, syna Dawidowego, syna Abrahamowego.
Abraham spłodził Izaaka, a Izaak spłodził Jakóba, a Jakób spłodził Judę, i braci jego.
A Juda spłodził Faresa i Zarę z Tamary, a Fares spłodził Hesrona, a Hesron spłodził Arama.
A Aram spłodził Aminadaba, a Aminadab spłodził Naasona, a Naason spłodził Salmona.
A Salmon spłodził Booza z Rachaby, a Booz spłodził Obeda z Ruty, a Obed spłodził Jessego.