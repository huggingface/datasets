Kniha (o) rodu Ježíše Krista syna Davidova, syna Abrahamova.
Abraham zplodil Izáka. Izák pak zplodil Jákoba. Jákob zplodil Judu a bratří jeho.
Šalomoun zplodil Roboáma. Roboám zplodil Abiáše. Abiáš zplodil Azu.
A po zajetí Babylonském Jekoniáš zplodil Salatiele. Salatiel pak zplodil Zorobábele.
A tak všech rodů od Abrahama až do Davida bylo rodů čtrnácte. A od Davida až do zajetí Babylonského rodů čtrnácte. A od zajetí Babylonského až do Krista rodů čtrnácte.