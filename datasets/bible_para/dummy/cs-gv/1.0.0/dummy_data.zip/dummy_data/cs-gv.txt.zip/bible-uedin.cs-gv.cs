Stalo se pak za času krále Asvera, (to jest ten Asverus, jenž kraloval od Indie až k Mouřenínské zemi nad sto dvadcíti a sedmi krajinami),
Že toho času, když seděl král Asverus na stolici království svého, jenž byla v Susan, městě královském,
Léta třetího kralování svého, učinil u sebe hody všechněm knížatům svým a služebníkům svým, nejznamenitějším Perským a Médským, hejtmanům a vládařům nad krajinami,
Ukazuje bohatství, slávu království svého a čest, i ozdobu důstojnosti své za mnoho dnů, totiž za sto a osmdesáte dnů.
(A když se vyplnili dnové ti, učinil král všemu lidu, což ho koli bylo v Susan městě královském, od největšího až do nejmenšího, hody za sedm dní na paláci v zahradě při domě královském.)