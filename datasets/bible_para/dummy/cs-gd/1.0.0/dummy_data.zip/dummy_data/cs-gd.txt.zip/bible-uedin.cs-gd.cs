Počátek evangelium Ježíše Krista, Syna Božího;
Jakož psáno jest v Prorocích: Aj, já posílám anděla svého před tváří tvou, kterýž připraví cestu tvou před tebou.
Hlas volajícího na poušti: Připravujte cestu Páně, přímé čiňte stezky jeho.
Křtil Jan na poušti a kázal křest pokání na odpuštění hříchů.
I vycházeli k němu ze vší krajiny Židovské i Jeruzalémští, a křtili se od něho všickni v Jordáně řece, vyznávajíce hříchy své.