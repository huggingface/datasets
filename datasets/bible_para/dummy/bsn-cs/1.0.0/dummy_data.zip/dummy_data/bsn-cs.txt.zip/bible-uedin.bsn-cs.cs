Kniha (o) rodu Ježíše Krista syna Davidova, syna Abrahamova.
Abraham zplodil Izáka. Izák pak zplodil Jákoba. Jákob zplodil Judu a bratří jeho.
Judas pak zplodil Fáresa a Záru z Támar. Fáres pak zplodil Ezroma. Ezrom zplodil Arama.
Aram pak zplodil Aminadaba. Aminadab pak zplodil Názona. Názon zplodil Salmona.
Salmon zplodil Bóza z Raab. A Bóz zplodil Obéda z Rut. Obéd pak zplodil Jesse.