Ten jest początek Ewangielii Jezusa Chrystusa, Syna Bożego.
Jako napisano w prorokach: Oto Ja posyłam Anioła mego przed obliczem twojem, który zgotuje drogę twoję przed tobą.
Głos wołającego na puszczy: Gotujcie drogę Pańską, proste czyńcie ścieżki jego.
Jan chrzcił na puszczy, i kazał chrzest pokuty na odpuszczenie grzechów.
I wychodziła do niego wszystka kraina Judzka, i Jeruzalemczycy, a wszyscy byli od niego chrzczeni w rzece Jordanie, wyznawając grzechy swoje.