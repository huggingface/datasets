Błogosławiony mąż, który nie chodzi w radzie niepobożnych, a na drodze grzesznych nie stoi, i na stolicy naśniewców nie siedzi;
Ale w zakonie Pańskim jest kochanie jego, a w zakonie jego rozmyśla we dnie i w nocy.
Albowiem będzie jako drzewo nad strumieniem wód w sadzone, które owoc swój wydaje czasu swego, a liść jego nie opada; i wszystko, cokolwiek czynić będzie, poszczęści się.
Lecz nie tak niepobożni; ale są jako plewa, którą wiatr rozmiata.
Przetoż się niepobożni na sądzie nie ostoją, ani grzesznicy w zgromadzeniu sprawiedliwych.