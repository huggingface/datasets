Blahoslavený ten muž, kterýž nechodí po radě bezbožných, a na cestě hříšníků nestojí, a na stolici posměvačů nesedá.
Ale v zákoně Hospodinově jest líbost jeho, a v zákoně jeho přemýšlí dnem i nocí.
Nebo bude jako strom štípený při tekutých vodách, kterýž ovoce své vydává časem svým, jehožto list nevadne, a cožkoli činiti bude, šťastně mu se povede.
Ne takť budou bezbožní, ale jako plevy, kteréž rozmítá vítr.
A protož neostojí bezbožní na soudu, ani hříšníci v shromáždění spravedlivých.