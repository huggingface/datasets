Země pak byla nesličná a pustá, a tma byla nad propastí, a Duch Boží vznášel se nad vodami.
I řekl Bůh: Buď světlo! I bylo světlo.
A viděl Bůh světlo, že bylo dobré; i oddělil Bůh světlo od tmy.
A nazval Bůh světlo dnem, a tmu nazval nocí. I byl večer a bylo jitro, den první.
Řekl také Bůh: Buď obloha u prostřed vod, a děl vody od vod!