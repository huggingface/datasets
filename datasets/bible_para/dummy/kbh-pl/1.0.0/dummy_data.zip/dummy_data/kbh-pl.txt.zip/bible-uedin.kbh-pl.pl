Księga o rodzie Jezusa Chrystusa, syna Dawidowego, syna Abrahamowego.
Abraham spłodził Izaaka, a Izaak spłodził Jakóba, a Jakób spłodził Judę, i braci jego.
A Salomon spłodził Roboama, a Roboam spłodził Abijasza, a Abijasz spłodził Azę.
A po zaprowadzeniu do Babilonu Jechonijasz spłodził Salatyjela, a Salatyjel spłodził Zorobabela.
A tak wszystkiego pokolenia od Abrahama aż do Dawida jest pokoleó czternaście, a od Dawida aż do zaprowadzenia do Babilonu, pokoleó czternaście, a od zaprowadzenia do Babilonu aż do Chrystusa, pokoleó czternaście.