I stało się za dni Aswerusa, (który Aswerus królował od Indyi aż do Murzyńskiej ziemi, nad stem i dwudziestą i siedmią krain.)
Że za onych dni, gdy siedział król Aswerus na stolicy królestwa swego, która była w Susan, mieście stołecznem,
Roku trzeciego królowania swego sprawił u siebie ucztę na wszystkich książąt swoich, i sług swoich, na hetmanów z Persów i z Medów, na przełożonych i na starostów onych krain,
Pokazując bogactwa, i chwałę królestwa swego, i zacność a ozdobę wielmożności swojej przez wiele dni, mianowicie przez sto i ośmdziesiąt dni.
(A gdy się dokończyły dni one, uczynił król na wszystek lud, co go kolwiek było w Susan, w mieście stołecznem, od największego aż do najmniejszego, ucztę przez siedm dni na sali w ogrodzie przy pałacu królewskim.)