﻿::::::::::::::::::::::: University of Trento - Italy ::::::::::::::::::::::::::::::::

:::::::::::: SICK (Sentences Involving Compositional Knowledge) data set ::::::::::::