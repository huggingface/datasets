The SimpleQuestions Dataset
--------------------------------------------------------
In this directory is the SimpleQuestions dataset collected for
research in automatic question answering.