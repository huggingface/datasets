European Medicines Agency
EMEA/ H/ C/ 471
EVROPSKÁ VEŘEJNÁ ZPRÁVA O HODNOCENÍ (EPAR)
ABILIFY
Souhrn zprávy EPAR určený pro veřejnost