(roky)
1 EUR =
1 Vzhledem k zaokrouhlení nemusí mezisoučty a součty odpovídat součtu všech uvedených čísel.
1) Základní úroková sazba pro hlavní refinanční operace Eurosystému se od operace, která bude vypořádána 16. března 2016, sníží o 5 bazických bodů na 0,00 %.
1, s účinností od 31. prosince 2010.