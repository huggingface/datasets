Description
===========

This folder contains Indonesian text summarization dataset,
roughly 19K tokenized news articles from (formerly) Shortir.com,