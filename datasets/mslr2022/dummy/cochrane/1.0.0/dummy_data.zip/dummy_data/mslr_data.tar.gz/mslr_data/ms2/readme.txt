Conversion script for MS^2 data:

To convert MS^2 data to the same format as Cochrane for the SDP workshop, run:
```
python convert_to_cochrane.py --input training_reviews.jsonl --output_prefix ms2_cochrane_conversions/train