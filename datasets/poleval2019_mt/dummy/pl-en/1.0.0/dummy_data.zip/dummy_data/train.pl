poprostu to zaprezentuję. 
11 mieści się w 12 raz. 
1 razy 11 jest 11. 
Odjąć. 
1, przepisujemy 0. 
11 mieści się w 10 zero razy. 
0 razy 11 jest 0. 
pozostaje reszty 10. 
11 mieści się w 20 10 razy z resztą 10. 
To zdecydowanie nie dzieli się równo. 
Tak więc mamy wszystkie nasze czynniki tutaj: 1,2,3,4,5,6,8,10, 
12,15,20,24,30,40,60 i 120. 
Zrobione! 
