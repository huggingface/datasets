W tym przykładzie mamy pomnożyć 65 razy 1.
Dosłownie potrzebujemy pomnożyć 65 - możemy zapisać to, że to jest
znak razy w ten sposób albo możemy to zapisać jako kropka
w ten sposób - ale to znaczy 65 razy 1.
I są dwa sposoby interpretowania tego.
Możecie spojrzeć na to jako na jedną liczbę 65 albo
możecie to ująć jako liczba 1 65 razy,
i wszystkie dodane.
Ale w każdym przypadku, jeśli macie jedno 65, to dosłownie
to będzie 65.
Cokolwiek razy 1 będzie równało się to cokolwiek,
cokolwiek to jest.
Tak więc, jeśli mam 3 razy 1, to będzie 3.
Jeśli mam 5 razy 1, otrzymamy 5, ponieważ dosłownie
wszystko to jest dosłownie mówiąc 5 razy.
Jeśli tu wstawię - nie wiem - 157 razy 1 to będzie 157.
