hemoglobina w pewnych czerwonych krwinkach może mieć dopiero parę sekund 
a obok masz inne które mogą mieć 120 dni 
tak więc średnia określa się na około 60 dni lub około 2 miesięcy 
więc na pomiarach tego odsetku, zdecydowanie nie uzyska się niczego starszego niż 120 dni 
i przeciętnie, wychodzi on na poziomie 2 miesięcy
