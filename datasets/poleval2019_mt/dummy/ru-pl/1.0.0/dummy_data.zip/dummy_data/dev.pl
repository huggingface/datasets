W tym przykładzie mamy pomnożyć 65 razy 1. 
Dosłownie potrzebujemy pomnożyć 65 - możemy zapisać to, że to jest 
znak razy w ten sposób albo możemy to zapisać jako kropka 
w ten sposób - ale to znaczy 65 razy 1. 
I są dwa sposoby interpretowania tego. 
Możecie spojrzeć na to jako na jedną liczbę 65 albo 
możecie to ująć jako liczba 1 65 razy, 
i wszystkie dodane. 
Ale w każdym przypadku, jeśli macie jedno 65, to dosłownie 
to będzie 65. 
Cokolwiek razy 1 będzie równało się to cokolwiek, 
cokolwiek to jest. 
To razy 1 będzie 
ponownie tym samym. 
Jeśli mam tutaj swego rodzaju puste miejsce razy 1, i 
mogę zapisać to jako symbol razy razy 1, 
to wtedy wynik będzie dokładnie ten sam jak to nasze puste miejsce. 
