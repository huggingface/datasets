Mieszkańcami Ziemi jest każdy z nas i wszyscy z osobna - ciepło lub zimno-krwiści, kręgowce, bezkręgowce
ptaki, gady, płazy, ryby oraz człekokształtne
Zatem ludzie nie są jedynym gatunkiem zamieszkującym planetę dzieląc ją z milionami innych stworzeń
Jednakże to człowiek jest mieszkańcem planety usiłującym zdominować Ziemię
Poprzez analogię do rasizmu i seksizmu dyskryminacja gatunków
Jeśli istota żywa cierpi nie ma mowy o usprawiedliwieniu dla nie uwzględniania takiego cierpienia.
na równi z podobnym cierpieniem jakiejkolwiek innej istoty.
wtedy gdy dochodziło do konfliktu interesów ich rasy z inną.
W każdej sytacji schemat jest identyczny
mimo tego zawsze dochodzi do pogwałcenia tego szacunku gdy słabsi znajdą się w konflikcie z silniejszymi
