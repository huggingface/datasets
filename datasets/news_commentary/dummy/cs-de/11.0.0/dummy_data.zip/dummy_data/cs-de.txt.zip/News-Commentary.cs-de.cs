Zlato za 10 000 dolarů?
SAN FRANCISCO – Vést racionální rozhovor o hodnotě zlata nikdy nebylo snadné.
V poslední době, kdy se ceny zlata zvedly o více než 300% za deset let, je to ještě těžší.
Loni v prosinci napsali kolegové-ekonomové Martin Feldstein a Nouriel Roubini komentáře, v nichž odvážně zpochybnili „býčí“ náladu na trhu a rozumně poukázali na rizika spojená se zlatem.
A co se nestalo?