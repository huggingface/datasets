GNOME
Výchozí motiv GNOME
V pořádku
Umění
Kamera