Yelp Review Full Star Dataset

Version 1, Updated 09/09/2015

ORIGIN