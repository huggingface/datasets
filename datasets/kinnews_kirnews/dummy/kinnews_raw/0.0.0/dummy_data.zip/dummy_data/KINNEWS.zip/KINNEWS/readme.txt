KinNews: Kinyarwanda News Classification Dataset

Version 1, Updated 02/10/2020