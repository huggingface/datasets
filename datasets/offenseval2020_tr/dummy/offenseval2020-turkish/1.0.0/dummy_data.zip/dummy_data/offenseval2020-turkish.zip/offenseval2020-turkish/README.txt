This archive contains Turkish offensive language corpus as used in
OffensEval 2020 shared task
<https://sites.google.com/site/offensevalsharedtask/home>. Please see
the competition web site for more information.