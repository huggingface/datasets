﻿========================

OffensEval 2020: Identifying and Categorizing Offensive Language in Social Media (SemEval 2020 - Task 12)
Turkish training data 
v 1.0: December 16 2019