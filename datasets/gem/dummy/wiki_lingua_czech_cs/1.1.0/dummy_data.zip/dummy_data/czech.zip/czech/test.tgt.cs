Vyberte si druh fazolí nebo jiných luštěnin ke klíčení. Namočte luštěniny v teplé vodě. Nechte klíčit tři celé dny. Osušte výhonky a uložte je v lednici.
Vyžívejte různé vizuální pomůcky. Vyberte si pomůcky, které se hodí k vašemu projevu. PowerPoint využívejte opatrně.
