Jezte třikrát denně. Zbavte se všech nezdravých potravin, které máte doma. Naučte se jíst zdravě i v restauracích. Snažte se jíst co nejvíce doma.
Cvičte. Zdřímněte si. Opláchněte si obličej studenou vodou. Jděte ven. Dejte si dvacetiminutovou procházku. Snažte se dostatečně spát.
