Please find more information at https://inklab.usc.edu/CommonGen/ .
Or you can email yuchen.lin@usc.edu 

The data inside this folder was created May 30th, 2020.