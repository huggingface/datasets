This is the 1.0 distribution of the The Multi-genre NLI (MultiNLI) Corpus.

License information and a detailed description of the corpus are included in the accompanying PDF.

If you use this corpus, please cite the attached data description paper.