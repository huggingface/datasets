This is Adversarial NLI, rounds 1-3, the 0.1 version. Date: Nov 1, 2019.

NOTE: This is an early version of the dataset! We may clean it further, pro-
vide additional analysis, or add more rounds, at any stage in the future.
Please keep this in mind as you use it in your work.