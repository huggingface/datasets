Poszczególne pozycje mogą nie sumować się ze względu na zaokrąglenia .
Navigation Path : Home &gt; The European Central Bank &gt; Akty prawne &gt; Wszystkie opinie EBC &gt; CON / 2009/58
The European Central Bank
Press
Events