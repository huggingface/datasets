budući da:
Opseg nadzora uzima u obzir rezultate aktivnosti prošlog nadzora i utvrđene prioritete u vezi sa sigurnošću.