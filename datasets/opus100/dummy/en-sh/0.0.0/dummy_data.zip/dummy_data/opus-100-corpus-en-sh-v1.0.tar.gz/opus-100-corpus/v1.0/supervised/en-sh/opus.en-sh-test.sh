prazepin
Te nacionalne pristupne točke mogu biti u obliku repozitorija, registra, internetskog portala ili slično.