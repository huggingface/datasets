Mami!
Jo, je to tak.