Zawsze to oglądamy.
Aby poznać