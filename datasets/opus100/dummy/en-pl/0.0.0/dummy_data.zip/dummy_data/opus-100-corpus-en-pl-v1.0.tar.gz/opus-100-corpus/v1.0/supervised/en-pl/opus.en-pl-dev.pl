Wbij w żyłę w zgięciu łokciowym i opatrz rękę.
Gwarantowane pożyczki _BAR_ _BAR_