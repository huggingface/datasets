@Author: Nabil Hossain
 	 nhossain@cs.rochester.edu
Date: 05/21/2020

This is the task dataset for SemEval-2020 Task 7: Assessing Humor in Edited News Headlines.