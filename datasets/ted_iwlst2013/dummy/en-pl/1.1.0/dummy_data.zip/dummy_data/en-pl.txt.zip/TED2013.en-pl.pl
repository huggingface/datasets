http://www.ted.com/talks/lang/pl/stephen_palumbi_following_the_mercury_trail.html
Według biologa Stephena Palumbiego istnieje silne i zadziwiające ogniwo łączące stan wód oceanów i nasze zdrowie. Wykazuje jak toksyny znajdujące się na dnie oceanicznego łańcucha pokarmowego dostają się do naszych organizmów, wyjawia szokującą historię o produktach japońskiego rynku rybnego skażonych toksynami. Jego praca ma na celu ocalenie oceanów i naszego zdrowia.
fish,health,mission blue,oceans,science
899
Stephen Palumbi: Podążając rtęciowym szlakiem