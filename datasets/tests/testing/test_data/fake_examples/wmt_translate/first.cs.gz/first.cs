běžím
zmizel
Plav
