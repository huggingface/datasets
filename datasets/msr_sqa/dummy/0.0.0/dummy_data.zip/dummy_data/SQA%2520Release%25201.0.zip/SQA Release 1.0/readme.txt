Microsoft Research Sequential Question Answering (SQA) Dataset

-------------------------------------------------------------------------------------------------------
Contact Persons:
	Scott Wen-tau Yih        scottyih@microsoft.com